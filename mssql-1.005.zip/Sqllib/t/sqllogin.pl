# This file provides login id, passwd and server info for the test programs
# which C<require> this file.
# You may need to edit it, to make it fit you server, Don't forget to remove
# sensitive information once you've tested! Default is local user and
# local server with no password.


$Uid = '';
$Pwd = '';
$Srv = '';

# Don't remove the 1, or else C<require> will fail!
1;

