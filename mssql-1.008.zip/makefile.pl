use ExtUtils::MakeMaker;
WriteMakefile(
   'NAME' => 'MSSQL',
   'DISTNAME' => '\zip\mssql',
   'VERSION_FROM' => 'Sqllib\sqllib.pm'
);
